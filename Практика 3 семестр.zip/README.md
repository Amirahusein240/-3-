# Практики 2020-2021 (осенний семестр) ФН1

## Бакалавры

[Первый курс](https://github.com/olekravchenko/bmstu_fs1_practices/tree/main/bach_1grade/2020-2021)

[Второй курс](https://github.com/olekravchenko/bmstu_fs1_practices/tree/main/bach_2grade/2020-2021)

[Третий курс](https://github.com/olekravchenko/bmstu_fs1_practices/tree/main/bach_3grade/2020-2021/problem)

[Четвёртый курс]


## Магистры
[Первый курс] - работа с научным руководителем

[Второй курс] - работа с научным руководителем
